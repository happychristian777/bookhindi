<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct(){
		 parent::__construct();
		 $this->load->model('UserModel');
		 $this->load->helper(array('form','url','file','download'));
		 $this->load->library('session');
		 $this->load->library('form_validation');
		 $this->load->library('Simplify');
		 $this->load->library('cart');
		 $this->load->database();
	}
	public function index()
	{
		$this->load->view('web/header');
		$this->load->view('web/home');
		$this->load->view('web/footer');
	}
	public function ins_contact()
	{
		$name=$this->input->post('name');
		$email=$this->input->post('email');
		$contact=$this->input->post('contact');
		$message=$this->input->post('message');
		$data=array(
			'name'=>$name,
			'email'=>$email,
			'contact'=>$contact,
			'message'=>$message
		);
		$res=$this->UserModel->ins_contact($data);
		if($res){
			$this->session->set_flashdata('success','Thank you for sending us a messgae !');
			redirect('User/contact');
		}
		else{
			$this->session->set_flashdata('failed','cant send message right now !');
			redirect('User/contact');
		}
	}
	public function check_payment($date,$iid,$mock_test)
	{
		$user_id=$this->session->userdata('user_id');
	
		$data=array(
			'user_id'=>$user_id,
			'timestamp'=>$date,
			'payment_id'=>$iid,
			'mock_test'=>$mock_test
		);
		$this->UserModel->ins_check_payment($data);
	}
	public function bypass_mt1()
	{
		$user_id=$this->session->userdata('user_id');
		$data=$this->UserModel->bypass_mt1($user_id);
		if($data){
		foreach($data as $row){
		//;	echo $row->timestamp;	
			if (time() - strtotime($row->timestamp) > 60*60*24) {
				print "Unauthorized, No payment found in last 24 hours";
			 } else {
				redirect('User/mt1_qp1_sg1','refresh:2');
			 }
		}	
	}	else{
		echo "No past payment on this mock test";
	}	
	}
	public function bypass_mt2()
	{
		$user_id=$this->session->userdata('user_id');
		$data=$this->UserModel->bypass_mt2($user_id);
		if($data>=1){
			foreach($data as $row){
				//;	echo $row->timestamp;	
					if (time() - strtotime($row->timestamp) > 60*60*24) {
						print "Unauthorized, No payment found in last 24 hours";
					 } else {
						redirect('User/mt1_qp1_sg1','refresh:2');
					 }
				}

		}else{
			echo "No past payment on this mock test";
		}
		
			
	}
	public function bypass_mt3()
	{
		$user_id=$this->session->userdata('user_id');
		$data=$this->UserModel->bypass_mt3($user_id);
		if($data){
		foreach($data as $row){
		//;	echo $row->timestamp;	
			if (time() - strtotime($row->timestamp) > 60*60*24) {
				print "Unauthorized, No payment found in last 24 hours";
			 } else {
				redirect('User/mt1_qp1_sg1','refresh:2');
			 }
		}	}
		else{
			echo "No past payment on this mock test";
		}	
	}
	public function load_login()
	{
		$this->load->view('web/header');
		$this->load->view('web/loginsign');
		$this->load->view('web/footer');
	}
	public function contact()
	{
		$this->load->view('web/header');
		$this->load->view('web/contact');
		$this->load->view('web/footer');
	}
	public function loadmock_mt1()
	{
		if($this->session->userdata('user_firstname')){
			$name['name']=$this->input->get('name');
			$this->load->view('web/header');
			$this->load->view('web/confirmation_mt1',$name);
			$this->load->view('web/footer');
		}else{
			$this->session->set_flashdata('login','Please login to continue MockTest !');
				redirect('User/');
		}
	}
	public function loadmock_mt2()
	{
		if($this->session->userdata('user_firstname')){
			$name['name']=$this->input->get('name');
			$this->load->view('web/header');
			$this->load->view('web/confirmation_mt2',$name);
			$this->load->view('web/footer');
		}else{
			$this->session->set_flashdata('login','Please login to continue MockTest !');
				redirect('User/');
		}
	}
	public function loadmock_mt3()
	{
		if($this->session->userdata('user_firstname')){
			$name['name']=$this->input->get('name');
			$this->load->view('web/header');
			$this->load->view('web/confirmation_mt3',$name);
			$this->load->view('web/footer');
		}else{
			$this->session->set_flashdata('login','Please login to continue MockTest !');
				redirect('User/');
		}
	}
	public function mt1p2()
	{
		$this->load->view('web/header');
		$this->load->view('web/mt1p2');
		$this->load->view('web/footer');
	}
	public function mt2p2()
	{
		$this->load->view('web/header');
		$this->load->view('web/mt2p2');
		$this->load->view('web/footer');
	}
	public function mt3p2()
	{
		$this->load->view('web/header');
		$this->load->view('web/mt3p2');
		$this->load->view('web/footer');
	}
	public function register_user()
	{
		$user_firstname=$this->input->post('user_firstname');
		$user_lastname=$this->input->post('user_lastname');
		$user_contact=$this->input->post('user_contact');
		$user_email=$this->input->post('user_email');
		$user_password=$this->input->post('user_password');
		$userData=array('user_firstname'=>$user_firstname,
		'user_lastname'=>$user_lastname,
		'user_contact'=>$user_contact,
		'user_email'=>$user_email,
		'user_password'=>base64_encode($user_password));
		$res=$this->UserModel->ins_user($userData);
		//$this->load->view()
		if($res){
				$this->session->set_flashdata('success','Thnk u for registering with Hindi NAATI mock test');
				redirect('User/');
		}
		else{
				echo "Failed";
		}
	}

	public function isUserLogin()
	{
		$email=$this->input->post('user_email');
		$password=$this->input->post('user_password');
		//$data=array('eamil'=>$email,'password'=>$password);
		$return=$this->UserModel->loginUser($email,$password);
		if(count($return)>0)
		{
			foreach($return as $row)
			{
				$sessionArray=array(
					'user_id'=>$row->user_id,
					'user_firstname'=>$row->user_firstname,
					'user_lastname'=>$row->user_lastname,
					'user_email'=>$row->user_email		
				);
			}
			$this->session->set_userdata($sessionArray);
		redirect('User/index');
		}
		else
		{
			echo "failed";
		}
	}
	public function load_dropdown()
	{
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/dropdown');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function calc()
	{
		$this->load->view('web/header');
		$this->load->view('web/confirmation');
		$this->load->view('web/footer');	
	}
	public function confirmation()
	{
		$this->load->view('web/header');
		$this->load->view('web/confirmation');
		$this->load->view('web/footer');
	}
	public function terms()
	{
		$this->load->view('web/header');
		$this->load->view('web/terms');
		$this->load->view('web/footer');
	}
	public function date()
	{
		if (time() - strtotime("2020-10-24 4:00:26") > 60*60*24) {
			print "Older than 24h";
		 } else {
			print "Newer than 24h";
		 }
	}

	public function check_mt1()
	{
		//check whether stripe token is not empty
		if(!empty($_POST['stripeToken']))
		{
			//get token, card and user info from the form
			$token  = $_POST['stripeToken'];
			$name = $_POST['name'];
			$email = $_POST['email'];
			$card_num = $_POST['card_num'];
			$card_cvc = $_POST['cvc'];
			$card_exp_month = $_POST['exp_month'];
			$card_exp_year = $_POST['exp_year'];
			$itemName=$_POST['item_name'];
		
			//include Stripe PHP library
			require_once APPPATH."third_party/stripe/init.php";
			//set api key
			$stripe = array(
			  "secret_key"      => "sk_test_51HBIYjGs7gNdeLPLtr4CueiNVrqQcJvTLffq8Ua6GiAnRRijrbMXLi9Aa6Iy6EYYmCmgcpsbcKzsMy4BGFmJphMI00HibnccTH",
			  "publishable_key" => "pk_test_51HBIYjGs7gNdeLPLvbl1EiRv5vWz6Jnr00LBSm4N0gFLGnx1KICtyNvUPhg2OYk0GK4cRydmg3PdcerwINK9DzUB00HWuYxN5a"
			);
			\Stripe\Stripe::setApiKey($stripe['secret_key']);
			//add customer to stripe
			$customer = \Stripe\Customer::create(array(
				'email' => $email,
				'source'  => $token
			));
			//item information
			$itemName = $this->input->post('item_name');;
			$itemNumber = "1";
			$itemPrice = $this->input->post('item_price');
			$itemTotal=$this->input->post('item_total');
			$qty = "1";
			$currency = "aud";
			$orderID = "1";
			/*
				$itemName = "stripe donation";
				$itemNumber = "PS123456";
				$itemPrice = 50;
				$curency = "inr";
				$itemName="proargi9+";
				orderID = "SKA92712";
			*/
			//charge a credit or a debit card
			$charge = \Stripe\Charge::create(array(
				'customer' => $customer->id,
				'amount'   => $itemPrice,
				'currency' => $currency,
				'description' => $itemNumber,
				'metadata' => array(
				'item_id' => $itemNumber
				)
			));
			
			//retrieve charge details
			$chargeJson = $charge->jsonSerialize();
			//check whether the charge is successful
			if($chargeJson['amount_refunded'] == 0 && empty($chargeJson['failure_code']) && $chargeJson['paid'] == 1 && $chargeJson['captured'] == 1)
			{
				//order details 
				$amount = $chargeJson['amount'];
				$balance_transaction = $chargeJson['balance_transaction'];
				$currency = $chargeJson['currency'];
				$status = $chargeJson['status'];
				$date = date("Y-m-d H:i:s");
				$date1= date("y-m-d H:i:s");
				//insert tansaction data into the database
				$dataDB = array(
					'name' => $name,
					'email' => $email, 
					'card_num' => $card_num, 
					'card_cvc' => $card_cvc, 
					'card_exp_month' => $card_exp_month, 
					'card_exp_year' => $card_exp_year, 
					'item_name' => $itemName, 
					'item_price' => $itemPrice/100, 
					'item_price_currency' => $currency, 
					'paid_amount' => $amount/100, 
					'paid_amount_currency' => $currency, 
					'txn_id' => $balance_transaction, 
					'payment_status' => $status,
					'created' => $date,
					'modified' => $date,
				);
		

				if ($this->db->insert('payments', $dataDB)) {
					if($this->db->insert_id() && $status == 'succeeded'){
					//	$data['insertID'] = $this->db->insert_id();
						$iid=$this->db->insert_id(); 
						$mock_test='1';
					//	$this->load->view('web/payment_success', $data);
						$this->check_payment($date,$iid,$mock_test);
						 redirect('User/mt1_qp1_sg1','refresh:2');
				
					}
					else{
						echo "Transaction has been failed";
					}
				}
				else
				{
					echo "not inserted. Transaction has been failed";
				}
			}
			else
			{
				echo "Invalid Token";
				$statusMsg = "";
			}
		}
	}
	public function check_payment_mt1()
	{
		
	}
	public function check_payment_mt2()
	{

	}
	public function check_payment_mt3()
	{

	}

	public function check_mt2()
	{
		//check whether stripe token is not empty
		if(!empty($_POST['stripeToken']))
		{
			//get token, card and user info from the form
			$token  = $_POST['stripeToken'];
			$name = $_POST['name'];
			$email = $_POST['email'];
			$card_num = $_POST['card_num'];
			$card_cvc = $_POST['cvc'];
			$card_exp_month = $_POST['exp_month'];
			$card_exp_year = $_POST['exp_year'];
			$itemName=$_POST['item_name'];
		
			//include Stripe PHP library
			require_once APPPATH."third_party/stripe/init.php";
			//set api key
			$stripe = array(
			  "secret_key"      => "sk_test_51HBIYjGs7gNdeLPLtr4CueiNVrqQcJvTLffq8Ua6GiAnRRijrbMXLi9Aa6Iy6EYYmCmgcpsbcKzsMy4BGFmJphMI00HibnccTH",
			  "publishable_key" => "pk_test_51HBIYjGs7gNdeLPLvbl1EiRv5vWz6Jnr00LBSm4N0gFLGnx1KICtyNvUPhg2OYk0GK4cRydmg3PdcerwINK9DzUB00HWuYxN5a"
			);
			\Stripe\Stripe::setApiKey($stripe['secret_key']);
			//add customer to stripe
			$customer = \Stripe\Customer::create(array(
				'email' => $email,
				'source'  => $token
			));
			//item information
			$itemName = $this->input->post('item_name');;
			$itemNumber = "1";
			$itemPrice = $this->input->post('item_price');
			$itemTotal=$this->input->post('item_total');
			$qty = "1";
			$currency = "aud";
			$orderID = "1";
			/*
				$itemName = "stripe donation";
				$itemNumber = "PS123456";
				$itemPrice = 50;
				$curency = "inr";
				$itemName="proargi9+";
				orderID = "SKA92712";
			*/
			//charge a credit or a debit card
			$charge = \Stripe\Charge::create(array(
				'customer' => $customer->id,
				'amount'   => $itemPrice,
				'currency' => $currency,
				'description' => $itemNumber,
				'metadata' => array(
				'item_id' => $itemNumber
				)
			));
			
			//retrieve charge details
			$chargeJson = $charge->jsonSerialize();
			//check whether the charge is successful
			if($chargeJson['amount_refunded'] == 0 && empty($chargeJson['failure_code']) && $chargeJson['paid'] == 1 && $chargeJson['captured'] == 1)
			{
				//order details 
				$amount = $chargeJson['amount'];
				$balance_transaction = $chargeJson['balance_transaction'];
				$currency = $chargeJson['currency'];
				$status = $chargeJson['status'];
				$date = date("Y-m-d H:i:s");
				$date1=date("y-m-d H:i:s");
				//insert tansaction data into the database
				$dataDB = array(
					'name' => $name,
					'email' => $email, 
					'card_num' => $card_num, 
					'card_cvc' => $card_cvc, 
					'card_exp_month' => $card_exp_month, 
					'card_exp_year' => $card_exp_year, 
					'item_name' => $itemName, 
					'item_price' => $itemPrice/100, 
					'item_price_currency' => $currency, 
					'paid_amount' => $amount/100, 
					'paid_amount_currency' => $currency, 
					'txn_id' => $balance_transaction, 
					'payment_status' => $status,
					'created' => $date,
					'modified' => $date,
				);

				if ($this->db->insert('payments', $dataDB)) {
					if($this->db->insert_id() && $status == 'succeeded'){
						$iid=$this->db->insert_id(); 
						$mock_test='2';
					//	$this->load->view('web/payment_success', $data);
						$this->check_payment($date,$iid,$mock_test);
						 redirect('User/mt2_qp1_sg1','refresh:2');
					}
					else{
						echo "Transaction has been failed";
					}
				}
				else
				{
					echo "not inserted. Transaction has been failed";
				}
			}
			else
			{
				echo "Invalid Token";
				$statusMsg = "";
			}
		}
	}
	public function check_mt3()
	{
		//check whether stripe token is not empty
		if(!empty($_POST['stripeToken']))
		{
			//get token, card and user info from the form
			$token  = $_POST['stripeToken'];
			$name = $_POST['name'];
			$email = $_POST['email'];
			$card_num = $_POST['card_num'];
			$card_cvc = $_POST['cvc'];
			$card_exp_month = $_POST['exp_month'];
			$card_exp_year = $_POST['exp_year'];
			$itemName=$_POST['item_name'];
		
			//include Stripe PHP library
			require_once APPPATH."third_party/stripe/init.php";
			//set api key
			$stripe = array(
			  "secret_key"      => "sk_test_51HBIYjGs7gNdeLPLtr4CueiNVrqQcJvTLffq8Ua6GiAnRRijrbMXLi9Aa6Iy6EYYmCmgcpsbcKzsMy4BGFmJphMI00HibnccTH",
			  "publishable_key" => "pk_test_51HBIYjGs7gNdeLPLvbl1EiRv5vWz6Jnr00LBSm4N0gFLGnx1KICtyNvUPhg2OYk0GK4cRydmg3PdcerwINK9DzUB00HWuYxN5a"
			);
			\Stripe\Stripe::setApiKey($stripe['secret_key']);
			//add customer to stripe
			$customer = \Stripe\Customer::create(array(
				'email' => $email,
				'source'  => $token
			));
			//item information
			$itemName = $this->input->post('item_name');;
			$itemNumber = "1";
			$itemPrice = $this->input->post('item_price');
			$itemTotal=$this->input->post('item_total');
			$qty = "1";
			$currency = "aud";
			$orderID = "1";
			/*
				$itemName = "stripe donation";
				$itemNumber = "PS123456";
				$itemPrice = 50;
				$curency = "inr";
				$itemName="proargi9+";
				orderID = "SKA92712";
			*/
			//charge a credit or a debit card
			$charge = \Stripe\Charge::create(array(
				'customer' => $customer->id,
				'amount'   => $itemPrice,
				'currency' => $currency,
				'description' => $itemNumber,
				'metadata' => array(
				'item_id' => $itemNumber
				)
			));
			
			//retrieve charge details
			$chargeJson = $charge->jsonSerialize();
			//check whether the charge is successful
			if($chargeJson['amount_refunded'] == 0 && empty($chargeJson['failure_code']) && $chargeJson['paid'] == 1 && $chargeJson['captured'] == 1)
			{
				//order details 
				$amount = $chargeJson['amount'];
				$balance_transaction = $chargeJson['balance_transaction'];
				$currency = $chargeJson['currency'];
				$status = $chargeJson['status'];
				$date = date("Y-m-d H:i:s");
				$date1=date("y-m-d H:i:s");
				//insert tansaction data into the database
				$dataDB = array(
					'name' => $name,
					'email' => $email, 
					'card_num' => $card_num, 
					'card_cvc' => $card_cvc, 
					'card_exp_month' => $card_exp_month, 
					'card_exp_year' => $card_exp_year, 
					'item_name' => $itemName, 
					'item_price' => $itemPrice/100, 
					'item_price_currency' => $currency, 
					'paid_amount' => $amount/100, 
					'paid_amount_currency' => $currency, 
					'txn_id' => $balance_transaction, 
					'payment_status' => $status,
					'created' => $date,
					'modified' => $date,
				);

				if ($this->db->insert('payments', $dataDB)) {
					if($this->db->insert_id() && $status == 'succeeded'){
						$iid=$this->db->insert_id(); 
						$mock_test='3';
					//	$this->load->view('web/payment_success', $data);
						$this->check_payment($date,$iid,$mock_test);
						 redirect('User/mt3_qp1_sg1','refresh:2');
					}
					else{
						echo "Transaction has been failed";
					}
				}
				else
				{
					echo "not inserted. Transaction has been failed";
				}
			}
			else
			{
				echo "Invalid Token";
				$statusMsg = "";
			}
		}
	}
	public function load_checkout_mt1()
	{
		$data['item_amount']=$this->input->post('calc');
		$data['item_name']=$this->input->post('item_name');
		$this->load->view('web/header');
		$this->load->view('web/checkout_mt1',$data);
		$this->load->view('web/footer');
	}
	public function load_checkout_mt2()
	{
		$data['item_amount']=$this->input->post('calc');
		$data['item_name']=$this->input->post('item_name');
		$this->load->view('web/header');
		$this->load->view('web/checkout_mt2',$data);
		$this->load->view('web/footer');
	}
	public function load_checkout_mt3()
	{
		$data['item_amount']=$this->input->post('calc');
		$data['item_name']=$this->input->post('item_name');
		$this->load->view('web/header');
		$this->load->view('web/checkout_mt3',$data);
		$this->load->view('web/footer');
	}
	public function payment_success()
	{
		$this->load->view('web/payment_success');
	}
	public function payment_error()
	{
		$this->load->view('web/payment_error');
	}
	public function load_home()
	{
		$this->load->view('web/header');
		$this->load->view('web/home');
		$this->load->view('web/footer');
	}
	public function load_about()
	{
		$this->load->view('web/header');
		$this->load->view('web/about');
		$this->load->view('web/footer');
	}
	public function load_contact()
	{
		$this->load->view('web/header');
		$this->load->view('web/contact');
		$this->load->view('web/footer');
	}
	//MockTest1 data//
	public function mt1_qp1_sg1(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment1');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp1_sg2(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment2');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp1_sg3(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment3');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp1_sg4(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment4');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp1_sg5(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment5');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp1_sg6(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment6');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp1_sg7(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment7');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp1_sg8(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment8');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp1_sg9(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment9');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp1_sg10(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment10');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp1_sg11(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment11');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp1_sg12(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp1/segment12');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg1(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment1');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg2(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment2');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg3(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment3');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg4(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment4');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg5(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment5');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg6(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment6');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg7(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment7');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg8(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment8');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg9(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment9');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg10(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment10');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg11(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment11');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt1_qp2_sg12(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt1/qp2/segment12');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	//MockTest 2 data//
	public function mt2_qp1_sg1(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment1');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp1_sg2(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment2');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp1_sg3(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment3');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp1_sg4(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment4');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp1_sg5(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment5');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp1_sg6(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment6');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp1_sg7(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment7');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp1_sg8(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment8');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp1_sg9(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment9');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp1_sg10(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment10');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp1_sg11(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment11');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp1_sg12(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp1/segment12');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg1(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment1');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg2(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment2');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg3(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment3');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg4(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment4');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg5(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment5');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg6(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment6');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg7(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment7');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg8(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment8');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg9(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment9');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg10(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment10');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg11(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment11');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt2_qp2_sg12(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt2/qp2/segment12');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	//MockTest 3 data//
	public function mt3_qp1_sg1(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment1');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp1_sg2(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment2');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp1_sg3(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment3');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp1_sg4(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment4');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp1_sg5(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment5');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp1_sg6(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment6');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp1_sg7(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment7');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp1_sg8(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment8');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp1_sg9(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment9');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp1_sg10(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment10');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp1_sg11(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment11');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp1_sg12(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp1/segment12');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg1(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment1');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg2(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment2');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg3(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment3');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg4(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment4');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg5(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment5');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg6(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment6');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg7(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment7');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg8(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment8');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg9(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment9');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg10(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment10');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg11(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment11');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function mt3_qp2_sg12(){
		if($this->session->userdata('user_id'))
		{
			$this->load->view('web/header');
			$this->load->view('web/mt3/qp2/segment12');
			$this->load->view('web/footer');
		}
		else{
			redirect('User/');
		}
	}
	public function base()
	{
		$user='root';
		$pass='';
		$db='bookhindi';
		
		$con=mysqli_connect('localhost',$user, $pass, $db);
		
		
		$user_id=2;
		$user_firstname='Hello';
		$user_lastname='Hello';
		$user_email='Hello';
		$segment='Hello';
		$question_paper='Hello';
		$mock_test='Hello';
		$submitted_at='Hello';
		$user_file='Hello';


		$sql="insert into data (user_id,user_firstname,user_lastname,user_email,submitted_at,mock_test,question_paper,segment,user_file) values('$user_id','$user_firstname','$user_lastname','$user_email','$user_file','$submitted_at','$mock_test','$question_paper','$segment')";
		$query=mysqli_query($con,$sql);
		if($query)
		{
			echo "No Error In Adding Product";
		}
		else{

			echo "Error In Adding Product";
		}
	}



	public function save_rec(){
	//local
	$user='root';
	$pass='';
	$db='bookhindi';
	
	$con=mysqli_connect('localhost',$user, $pass, $db);
	
	$user_id=$this->session->userdata('user_id');
	$user_firstname=$this->session->userdata('user_firstname');
	$user_lastname=$this->session->userdata('user_lastname');
	$user_email=$this->session->userdata('user_email');
	$segment=$this->input->get('segment');
	$question_paper=$this->input->get('question_paper');
	$mock_test=$this->input->get('mock_test');
	$submitted_at=date('d:m:y');
	$user_file=$_POST['audio-filename'];

	$sql="insert into data (user_id,user_firstname,user_lastname,user_email,submitted_at,mock_test,question_paper,segment,user_file) values('$user_id','$user_firstname','$user_lastname','$user_email','$submitted_at','$mock_test','$question_paper','$segment','$user_file')";
	$query=mysqli_query($con,$sql);


	function someFunction($errno, $errstr) {
		echo '<h2>Upload failed.</h2><br>';
		echo '<p>'.$errstr.'</p>';
	}

	function selfInvoker()
	{
		if (!isset($_POST['audio-filename']) && !isset($_POST['video-filename'])) {
			echo 'Empty file name.';
			return;
		}

		// do NOT allow empty file names
		if (empty($_POST['audio-filename']) && empty($_POST['video-filename'])) {
			echo 'Empty file name.';
			return;
		}

		// do NOT allow third party audio uploads
		if (false && isset($_POST['audio-filename']) && strrpos($_POST['audio-filename'], "RecordRTC-") !== 0) {
			echo 'File name must start with "RecordRTC-"';
			return;
		}

		// do NOT allow third party video uploads
		if (false && isset($_POST['video-filename']) && strrpos($_POST['video-filename'], "RecordRTC-") !== 0) {
			echo 'File name must start with "RecordRTC-"';
			return;
		}
				

		
		$fileName = '';
		$tempName = '';
		$file_idx = '';
		
		if (!empty($_FILES['audio-blob'])) {
			$file_idx = 'audio-blob';
			$fileName = $_POST['audio-filename'];
			$tempName = $_FILES[$file_idx]['tmp_name'];
		} else {
			$file_idx = 'video-blob';
			$fileName = $_POST['video-filename'];
			$tempName = $_FILES[$file_idx]['tmp_name'];
		}
		
		if (empty($fileName) || empty($tempName)) {
			if(empty($tempName)) {
				echo 'Invalid temp_name: '.$tempName;
				return;
			}

			echo 'Invalid file name: '.$fileName;
			return;
		}

		/*
		$upload_max_filesize = return_bytes(ini_get('upload_max_filesize'));

		if ($_FILES[$file_idx]['size'] > $upload_max_filesize) {
		echo 'upload_max_filesize exceeded.';
		return;
		}

		$post_max_size = return_bytes(ini_get('post_max_size'));

		if ($_FILES[$file_idx]['size'] > $post_max_size) {
		echo 'post_max_size exceeded.';
		return;
		}
		*/

		$filePath =  'uploads/' . $fileName;

		// make sure that one can upload only allowed audio/video files
		$allowed = array(
			'webm',
			'wav',
			'mp4',
			'mkv',
			'mp3',
			'ogg'
		);
		$extension = pathinfo($filePath, PATHINFO_EXTENSION);
		if (!$extension || empty($extension) || !in_array($extension, $allowed)) {
			echo 'Invalid file extension: '.$extension;
			return;
		}
		
		if (!move_uploaded_file($tempName, $filePath)) {
			if(!empty($_FILES["file"]["error"])) {
				$listOfErrors = array(
					'1' => 'The uploaded file exceeds the upload_max_filesize directive in php.ini.',
					'2' => 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.',
					'3' => 'The uploaded file was only partially uploaded.',
					'4' => 'No file was uploaded.',
					'6' => 'Missing a temporary folder. Introduced in PHP 5.0.3.',
					'7' => 'Failed to write file to disk. Introduced in PHP 5.1.0.',
					'8' => 'A PHP extension stopped the file upload. PHP does not provide a way to ascertain which extension caused the file upload to stop; examining the list of loaded extensions with phpinfo() may help.'
				);
				$error = $_FILES["file"]["error"];

				if(!empty($listOfErrors[$error])) {
					echo $listOfErrors[$error];
				}
				else {
					echo 'Not uploaded because of error #'.$_FILES["file"]["error"];
				}
			}
			else {
				echo 'Problem saving file: '.$tempName;
			}
			return;
		}

	echo "success";
	}


	/*
	function return_bytes($val) {
		$val = trim($val);
		$last = strtolower($val[strlen($val)-1]);
		switch($last) {
			// The 'G' modifier is available since PHP 5.1.0
			case 'g':
				$val *= 1024;
			case 'm':
				$val *= 1024;
			case 'k':
				$val *= 1024;
		}

		return $val;
	}
	*/

	selfInvoker();
		}

		public function logout()
		{
			session_destroy();
			redirect('User/index');
		}
		public function finish()
		{
		//	$this->load->view('web/header');
			$this->load->view('web/finish_test');
		//	$this->load->view('web/footer');
		}

}
