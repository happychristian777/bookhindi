<nav id="breadcrumbs" class="breadcrumbs">
		<div class="container page-wrapper">
			<a href="index.html">Home</a> » <span class="breadcrumb_last" aria-current="page">Login/Signup</span>
		</div>
	</nav>
<section class="w3l-contact-main">
		<div class="contact-infhny py-3">
			<div class="container py-lg-3">
				<div class="title-content text-left mb-lg-5 mt-4">
					<h6 class="sub-title">Signup/Login</h6>

				</div>
				<div class="row align-form-map">
					<div class="col-lg-6 form-inner-cont">
						<form  action="<?php echo base_url();?>User/register_user" method="post" class="signin-form">
							<div class="form-input">
                                <label style="color:blue;"><u><b>Register Here</b></u></label>
                                <div class="form-input">
								<label for="w3lSender">First Name*</label>
								<input type="text" name="user_firstname" id="w3lSender" placeholder="" required="" />
							</div>
                            <div class="form-input">
								<label for="w3lSender">Last Name*</label>
								<input type="text" name="user_lastname" id="w3lSender" placeholder="" required="" />
							</div>
                            <div class="form-input">
								<label for="w3lSender">Contact Number*</label>
								<input type="text" name="user_contact" id="w3lSender" placeholder="" required="" />
							</div>
								<label for="w3lName">Email*</label>
								<input type="email" name="user_email" id="w3lName" placeholder="" />
							</div>
							<div class="form-input">
								<label for="w3lSender">Password*</label>
								<input type="password" id="txtPassword" name="user_password" id="w3lSender" placeholder="" required="" />
							</div>

							<div class="form-input">
								<label for="w3lMessage">Re-Type Password*</label>
								<input type="password" id="txtConfirmPassword" name="" id="w3lSender" placeholder="" required="" />
							</div>
                            
                         
                          		<input type="submit" id="btnSubmit" style="background:darkturquoise;color:white" value="Register" type="submit" class="btn btn-contact">

						</form>

                        
					</div>

                    <div class="col-lg-6 form-inner-cont">
						<form  action="<?php echo base_url();?>User/isUserLogin" method="post" class="signin-form">
							<div class="form-input">
                            <div class="form-input">
                                <label style="color:blue;"><u><b>Login Here</b></u></label>
								<label for="w3lName">Email*</label>
								<input type="email" name="user_email" id="w3lName" placeholder="" />
							</div>
							<div class="form-input">
								<label for="w3lSender">Password*</label>
								<input type="password" name="user_password" id="w3lSender" placeholder="" required="" />
							</div>
							<a href="#">Forget Password</a>
							<input type="submit" style="background:darkturquoise;color:white"  value="Login" class="btn btn-contact">

						</form>

                        
					</div>
				
				
				</div>
			</div>
            
            
	</section>
	<script type="text/javascript">
    $(function () {
        $("#btnSubmit").click(function () {
            var password = $("#txtPassword").val();
            var confirmPassword = $("#txtConfirmPassword").val();              
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            return true;
        });
    });
</script>