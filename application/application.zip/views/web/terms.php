<nav id="breadcrumbs" class="breadcrumbs">
		<div class="container page-wrapper">
			<a href="<?php echo base_url();?>">Home</a> » <span class="breadcrumb_last" aria-current="page">Terms & Conditions</span>
		</div>
	</nav>

	
    <section class="w3l-feature-1">
	<div class="feature-1sec py-5">
		<div class="container py-lg-5">
			<div class="feature-1-content">
				
							<div class="read">
                <h5 class="hny-title mt-4">  DISCLAIMER:</h5>
                <p class="mt-2">The results from this Mock Exam Score Report should be used as a guide only. We make no guarantee that this will reflect the scores on your real exam. Questions from the mock exam are intended for use as exam revision or as a personal development resource only. Whilst we have made every effort to provide questions in a format as close to the real exam as possible, the questions contained herein may not be an accurate reflection of the types of questions on the real exam. To ensure your best chances of obtaining good scores, make sure you react to the specific questions on the day of your real exam. Good luck!.</p>
				</div>
			</div>
		</div>
	</div>
</section>
	<!-- //content-6-section -->
	<!--/team-sec-->
	
		