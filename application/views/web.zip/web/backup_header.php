<!doctype html>
<html lang="zxx">
<head>
  <title>Naati Mock Test (Proctor Exam Mock Ups)Provides You an Amazing Offer for $20 Only. You Can Download List of Exam Repeated Important Words and Phrases Related to Legal Terms You Can Download List of Exam Repeated Important Words and Phrases Related to Legal Terms, Medical Terms, Finance and Banking, Business, Housing Terms, Education Terms, Employment Terms, Social Welfare Terms, Immigration Terms, Ethics Terms</title>
   <meta name="description" content="Naati Mock Test (Proctor Exam Mock Ups) with Multi-Languages like Hindi, Punjabi, Tamil, Urdu, Nepali, Indonesian provides you with exam repeated most important words, phrase and mock test on- Legal, Medical, Banking, Business, Housing, Education, Employment, Social Welfare, Immigration - Naati Mock Test" />
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-184736136-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-184736136-1');
</script>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	</title>
	<!-- Template CSS -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/assets_home/css/style-starter.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<!-- Template CSS -->
	<link href="//fonts.googleapis.com/css?family=Poppins:300,400,400i,500,600,700&display=swap" rel="stylesheet">
	<!-- Template CSS -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css">
	<!-- Facebook Pixel Code --><script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js'); fbq('init', '824720404926702'); fbq('track', 'PageView');</script><noscript> <img height="1" width="1" src="https://www.facebook.com/tr?id=824720404926702&ev=PageView&noscript=1"/></noscript><!-- End Facebook Pixel Code -->
</head>

<body>
	<!--w3l-header-->
	<section class="w3l-top-header-content">
		<div class="hny-top-menu">
			<div class="container">
				<div class="row">
					<div class="top-left col-lg-6 col-sm-12">
						<ul class="accounts">
							<li class="top_li"><span class="fa fa-map"></span> <a href="#">
								Australia</a>
							</li>
							<li class="top_li mr-lg-0"> <a href="mailto:naatimocktests@gmail.com" class="mail"><span class="fa fa-envelope"></span>naatimocktests@gmail.com<a>

							</li>
						</ul>
					</div>
					<div class="social-top col-lg-6 mt-lg-0 mt-sm-3">
					<div class="top-bar-text"><?php if($this->session->userdata('user_firstname')){?><a class="bk-button" href="<?php echo base_url();?>User/logout">Logout </a> <?php } else { ?><a class="bk-button" href="<?php echo base_url();?>User/load_login">Login/Register </a><?php } ?>
						Welcome <?php echo  $this->session->userdata('user_firstname');?></div>
					</div>
					<?php if($this->session->flashdata('success')){ ?>
					<div class="alert alert-danger" role="alert" id="success-alert">
					<strong id="myWish"><?php echo $this->session->flashdata('success');?></strong>
					</div>
					<?php } ?>
					<?php if($this->session->flashdata('login')){ ?>

					<div style="margin-left:400px;" class="alert alert-danger" role="alert" id="success-alert">
					<strong id="myWish"><?php echo $this->session->flashdata('login');?></strong>
					</div>

					<?php } ?>
				</div>
			</div>
		</div>
	</section>
	<!--//top-header-content-->
	<!--w3l-header-->
	<header class="w3l-header-nav">
		<!--/nav-->
		<nav class="navbar navbar-expand-lg navbar-light px-lg-0 py-0 px-3 stroke">
			<div class="container">
				<a class="navbar-brand" href="<?php echo base_url();?>"><img style="height:150px;width:180px;" src="<?php echo base_url();?>assets/assets_home/images/logo1.jpeg"></img></a>
				<!-- if logo is image enable this
						<a class="navbar-brand" href="#index.html">
						<img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
				</a> -->
				<button class="navbar-toggler collapsed" type="button" data-toggle="collapse"
					data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
					aria-label="Toggle navigation">
					<span class="fa icon-expand fa-bars"></span>
					<span class="fa icon-close fa-times"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbarSupportedContent">
					<ul class="navbar-nav mx-lg-auto">
						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url();?>">Home</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url();?>User/load_about">About</a>
						</li>
					<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url();?>User/load_study_material?name=study_material">Study Material</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url();?>User/load_buy_hindi">Hindi</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url();?>User/load_buy_punjabi">Punjabi</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url();?>User/load_buy_tamil">Tamil</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url();?>User/load_buy_urdu">Urdu</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url();?>User/load_buy_nepali">Nepali</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url();?>User/load_buy_indonesian">Gujarati</a>
						</li>
							<li class="nav-item">
						<!--	<a class="nav-link" href="<?php echo base_url();?>User/load_access_material?name=access_material">A</a> -->
						</li>

						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url();?>User/contact">Contact Us</a>
						</li>
					</ul>

					<!--<div class="call-support">
						<p>Call us for any questions</p>
						<h5>+61 469738009</h5>
					</div>-->
				</div>
			</div>
		</nav>
		<!--//nav-->
	</header>

<script>
    $(function(){
        $('a').each(function(){
            if ($(this).prop('href') == window.location.href) {
                $(this).addClass('active'); $(this).parents('li').addClass('active');
            }
        });
    });
</script>

<style>
@media (max-width: 600px){
.w3l-top-header-content {
    width:150%;
}
}
    </style>
</style>